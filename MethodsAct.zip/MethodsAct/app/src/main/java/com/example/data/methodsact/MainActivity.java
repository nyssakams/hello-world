package com.example.data.methodsact;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    //declare first all variables
        EditText etNo1,etNo2;
        Button btAdd,btMulti, btSub;
        TextView tvResult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //initialize variables
        initializeVars();


        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x = Integer.parseInt(etNo1.getText().toString()); //save no. into int with variable x ( kalau merah tekan - wrap using integer.parseInt() )
                int y = Integer.parseInt(etNo2.getText().toString()); //save no. into int y
                int z = addValues(x,y); //method add will pass x & y , kalau addValues merah sebab tak ada method add lagi
                tvResult.setText("Add value is :" + z);

            }
        });


        btMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x = Integer.parseInt(etNo1.getText().toString()); //save no. into int with variable x ( kalau merah tekan - wrap using integer.parseInt() )
                int y = Integer.parseInt(etNo2.getText().toString()); //save no. into int y
                int z = multiplyValues(x,y); //method multiply will pass x & y , kalau addValues merah sebab tak ada method add lagi
                tvResult.setText("Multiply value is :" + z);
            }
        });

        btSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x = Integer.parseInt(etNo1.getText().toString()); //save no. into int with variable x ( kalau merah tekan - wrap using integer.parseInt() )
                int y = Integer.parseInt(etNo2.getText().toString()); //save no. into int y
                int z = subtractValues(x,y); //method subtract will pass x & y , kalau subtractValues merah sebab tak ada method add lagi,kena alt+enter & tekan create method+buat method subtract pada method/mainactivity
                tvResult.setText("Subtract value is :" + z);

            }
        });






    }

    private int subtractValues(int x, int y) {
        int result = x-y; // letak return x-y je
        return result;

    }


    private int multiplyValues(int x, int y) {
        int result = x*y; // letak return x*y je
        return result;
    }

    private int addValues(int x, int y) {

        int result = x + y; //letak sini return x+y je
        return result;

    }





    private void initializeVars() {
        etNo1 = findViewById(R.id.editText1);
        etNo2 = findViewById(R.id.editText2);
        tvResult = findViewById(R.id.textViewResult);
        btAdd = findViewById(R.id.buttonAdd);
        btMulti = findViewById(R.id.buttonMultiply);
        btSub = findViewById(R.id.buttonSubtract);
    }
}
