package com.tk2323.ftsm.workshop_android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class History_Activity extends AppCompatActivity {

    RecyclerView recyclerHistory;
    TextView textNameReceived;
    Button btnDelete; // no 17
    List<HistoryData> historyDataList; //no 17

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_); // tengah pegang class activity history

        textNameReceived = findViewById(R.id.tvNameReceived);
        recyclerHistory = findViewById(R.id.rvHistory);

      /*  HistoryData historyData[] = {new HistoryData("Esther", "Master Room", "12pm", "On"),
                new HistoryData("Salina", "Living Room", "1pm", "On"),
                new HistoryData("Mardhiah", "Master Room", "2pm", "On"),
                new HistoryData("Chung", "Dining Room", "10am", "Off"),
                new HistoryData("Haslina", "Living Room", "11pm", "On"),
                new HistoryData("Lam", "Master Room", "2pm", "On"),
                new HistoryData("Niza", "Master Room", "8pm", "Off"),
        };


        recyclerHistory.setLayoutManager(new StaggeredGridLayoutManager(1, 1));

        recyclerHistory.addItemDecoration(new DividerItemDecoration(History_Activity.this, DividerItemDecoration.VERTICAL));

       MyAdapter myAdapter = new MyAdapter(historyData, getApplicationContext());
        recyclerHistory.setAdapter(myAdapter);
*/

      refreshList();
        LinearLayoutManager LinearLayoutManager = new LinearLayoutManager(this);
        LinearLayoutManager.setStackFromEnd(true);
        LinearLayoutManager.setReverseLayout(true);

        recyclerHistory.setLayoutManager(LinearLayoutManager);
        recyclerHistory.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);

    }

    private void refreshList() {

        HistoryDBHandler historyhandler = new HistoryDBHandler(this, HistoryDBHandler.DATABASE_NAME, null, HistoryDBHandler.DATABASE_VERSION);
        historyDataList = historyhandler.findAllHistory();
        historyDataList.toString();
        MyAdapter myAdapter = new MyAdapter(historyDataList, getApplicationContext());
        recyclerHistory.setAdapter(myAdapter);

        btnDelete = findViewById(R.id.buttonDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                HistoryDBHandler historyDBHandler = new HistoryDBHandler(getApplicationContext(),HistoryDBHandler.DATABASE_VERSION);
                historyDBHandler.deleteAllHistory();
                refreshlist();


            }
        });






    }
}
