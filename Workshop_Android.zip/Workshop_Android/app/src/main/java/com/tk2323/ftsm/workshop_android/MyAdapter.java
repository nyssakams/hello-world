package com.tk2323.ftsm.workshop_android;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Data on 25/2/2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_item_layout,null);

     ViewHolder viewHolder = new ViewHolder(itemView);

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

/*
        holder.tvName.setText(historyDatas[position].getName());
        holder.tvRoomType.setText(historyDatas[position].getRoomType());
        holder.tvDateTime.setText(historyDatas[position].getDateTime());
        holder.tvStatus.setText(historyDatas[position].getStatus());
*/

        holder.tvName.setText(historyDatas.get(position).getName());
        holder.tvRoomType.setText(historyDatas.get(position).getRoomType());
        holder.tvDateTime.setText(historyDatas.get(position).getDateTime());
        holder.tvStatus.setText(historyDatas.get(position).getStatus());





    }


    @Override
    public int getItemCount() {

        // Length is for array
        //size is for List

        //return historyDatas.length;

        return historyDatas.size(); //No.17


    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvName, tvRoomType, tvDateTime, tvStatus;


        public ViewHolder(View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvRoomType = itemView.findViewById(R.id.tvRoomType);
            tvDateTime = itemView.findViewById(R.id.tvDateTime);
            tvStatus = itemView.findViewById(R.id.tvStatus);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(mContext, tvName.getText().toString() +
                            " " + tvRoomType.getText().toString() + "\n" + tvDateTime.getText().toString() +
                            " " + tvStatus.getText().toString(), Toast.LENGTH_SHORT ).show(); } });



        }

    }

    //HistoryData[] historyDatas;
    HistoryData> historyDatas;
    Context mContext;

    public MyAdapter(HistoryData[] historyDatas, Context mContext) {
        this.historyDatas = historyDatas;
        this.mContext = mContext;
    }

}