package com.tk2323.ftsm.workshop_android;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {


    TextView textRoom;
    EditText editname;
    ToggleButton togglePower;
    Button buttonHistory, buttonExit;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);

        return super.onCreateOptionsMenu(menu);



    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int selectedID = item.getItemId();

        switch(selectedID){
            case R.id.menu_master:
              textRoom.setText("Master Room");
              break;
            case R.id.menu_living:
            textRoom.setText("Living Room");
            break;
            case R.id.menu_dining:
                textRoom.setText("Dining Room");
                break;

        }

        return super.onOptionsItemSelected(item);
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //tengah pegang layout activity main xml



        //call variable textRoom and panggil id yang sama pada layout
        textRoom = findViewById(R.id.tvRoom);
        editname = findViewById(R.id.etName);
        togglePower =  findViewById(R.id.tbPower);
        buttonHistory = findViewById(R.id.btnHistory);
        buttonExit =  findViewById(R.id.btnExit);


        buttonHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                                   //panggil lagi satu class iaitu history_activity
                Intent i = new Intent(MainActivity.this,History_Activity.class);

                String name = editname.getText().toString();
                i.putExtra("Name", name);


                startActivity(i);

                buttonHistory.setBackgroundColor(Color.GREEN);



            }
        });


        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(MainActivity.this);
                myAlertDialog.setTitle("Exit this Application?");
                myAlertDialog.setMessage("Hi, I am Alert Dialog");

                myAlertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                finish();




                            }
                        });

                myAlertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                       Toast.makeText(MainActivity.this,"Thanks",Toast.LENGTH_SHORT).show();


                    }
                });

                myAlertDialog.show();


                        buttonExit.setBackgroundColor(Color.RED);


            }
        });








        togglePower.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh-mm-ss dd-MM-yyyy");
                String format = simpleDateFormat.format(new Date());

                HistoryDBHandler historyDBHandler = new
                        HistoryDBHandler(MainActivity.this, HistoryDBHandler.DATABASE_NAME,
                        null, HistoryDBHandler.DATABASE_VERSION);
                String status = " ";



                if(isChecked){

                    Toast.makeText(MainActivity.this,"Light is On",Toast.LENGTH_SHORT).show();
                    status = "On";
                }

                else{
                    Toast.makeText(MainActivity.this,"Light is Off",Toast.LENGTH_LONG).show();
                    status = "Off";
                }

                HistoryData historyData= new
                        HistoryData(editname.getText().toString(),
                        textRoom.getText().toString(),
                        format, status); historyDBHandler.addHistory(historyData);


            }
        });












    }
}
