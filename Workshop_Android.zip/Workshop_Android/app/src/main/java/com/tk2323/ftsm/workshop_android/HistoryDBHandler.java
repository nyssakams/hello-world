package com.tk2323.ftsm.workshop_android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Data on 25/2/2018.
 */

public class HistoryDBHandler extends SQLiteOpenHelper {

    public static int DATABASE_VERSION = 1;
    public static String DATABASE_NAME = "History.DB.db";
    public static String DATABASE_TABLE_HISTORY = "history";
    public static String COLUMN_ID = "id";
    public static String COLUMN_NAME = "person_name";
    public static String COLUMN_ROOMTYPE = "room_type";
    public static String COLUMN_DATETIME = "date_time";
    public static String COLUMN_STATUS= "status";
    public static String CREATE_TABLE_HISTORY= "CREATE TABLE" + COLUMN_ID + " INTEGER PRIMARY KEY, " + COLUMN_NAME + " TEXT, " + COLUMN_ROOMTYPE + " TEXT, " + COLUMN_DATETIME+ " TEXT , " + COLUMN_STATUS + " TEXT, " + ")";





    public HistoryDBHandler(Context context,String name,SQLiteDatabase.CursorFactory factory,int version){

            super(context,DATABASE_NAME,factory,DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

  sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_HISTORY);
  onCreate(sqLiteDatabase);

    }

    public void addHistory(HistoryData historyData){

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_NAME, historyData.getName());
        cv.put(COLUMN_ROOMTYPE, historyData.getRoomType());
        cv.put(COLUMN_DATETIME, historyData.getDateTime());
        cv.put(COLUMN_STATUS, historyData.getStatus());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(DATABASE_TABLE_HISTORY, null, cv);
        db.close();
    }

    public List<HistoryData> findAllHistory(){
        List<HistoryData> HistoryDataList = new LinkedList<>();
        String findAllHistory = "Select * From " + DATABASE_TABLE_HISTORY;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(findAllHistory, null);

        HistoryData historyData = null;
        if (cursor.moveToFirst()){
            do {
                historyData = new HistoryData();

            historyData.set_id(Integer.parseInt(cursor.getString(0)));
            historyData.setName((cursor.getString(1)));
            historyData.setRoomType((cursor.getString(2)));
            historyData.setDateTime(cursor.getString(3));
            historyData.setStatus(cursor.getString(4));
            HistoryDataList.add(historyData);
            }while (cursor.moveToNext());
        }
        return HistoryDataList;
    }



    public void deleteAllHistory(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(DATABASE_TABLE_HISTORY, null, null);
    }










}
