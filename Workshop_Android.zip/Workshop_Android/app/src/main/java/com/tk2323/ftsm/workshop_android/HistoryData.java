package com.tk2323.ftsm.workshop_android;

import android.support.v7.widget.StaggeredGridLayoutManager;

/**
 * Created by Data on 25/2/2018.
 */

public class HistoryData {

    int _id;
    String name, roomType, dateTime, status;


    public HistoryData(String name, String roomType, String dateTime, String status){

        this.name = name;
        this.roomType = roomType;
        this.dateTime = dateTime;
        this.status = status;

    }


    public String getName() {
        return name;
    }

    public void setName(String name ){
        this.name = name;

    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType){
        this.roomType= roomType;
    }

    public String getDateTime(){
        return dateTime;
    }


    public void setDateTime(String dateTime){
        this.dateTime = dateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }


    public String toString(){
        return "History_id"+ _id +",Name"+ name +",Room Type"+roomType+ "\n";
    }


    public HistoryData(){

    }




}


