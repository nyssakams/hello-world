package com.example.data.convert;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class ConvertActivity extends AppCompatActivity {

    TextView tvCelsius;
    Button btconvert;
    Button btNext;
    EditText etFahrenheit;
    String s;
    double celsius;
    double fahrenheit;
    ImageView ivIcon;
    String condition= "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);

//important
        etFahrenheit = findViewById(R.id.editTextFahrenheit);
        btconvert = findViewById(R.id.buttonConvert);
        tvCelsius = findViewById(R.id.textViewCelsius);
        btNext = findViewById(R.id.buttonNext);
        ivIcon = findViewById(R.id.imageViewTemp);




        //functionality of button(to click the button)
        btconvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                
            convert(); //looks for method convert







            }
        });


        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //inside () determine where we want to go(from activity ConvertActivity kepada next actiovity iaitu nextactivity
                Intent i = new Intent(ConvertActivity.this, NextActivity.class);


                //BUlNDLE EVERYTHING TOGETHER. TO SEND A FEW THINGS TOGETHER&SEND IT TO THE NEXT PLACE. double,text/combination
                //or send condition

                Bundle bundle = new Bundle(); //step1 : create a bundle object
                //step2 : add your data to Bundle
                bundle.putString("key1",condition);
                bundle.putDouble("key2", celsius);
                // step 3 : add bundle to intent
                i.putExtras(bundle);

               // i.putExtra("key2",celsius);
                // important. kena ingat nama String untuk retrieve value tu. //String s = ""key"; i.putExtra(celsius);
                //transfer or send data from one activity to the next activity
                startActivity(i); //pass intent inside here
            }
        });


        //create new method





    }

    //create new method
    public void convert(){


        s = etFahrenheit.getText().toString();
        fahrenheit = Double.parseDouble(s);
        celsius = (fahrenheit-32)*(0.5556);
        Log.e("Clicked","I clicked btconvert " + s);
        DecimalFormat df = new DecimalFormat("##.##");
        //String finalcelsius = String.valueOf(celsius);
        double rounded  = Double.parseDouble(df.format(celsius));
        tvCelsius.setText(rounded  + " " + (char)186 + "C");

        //Toast.makeText(ConvertActivity.this, "Conversion Complete", Toast.LENGTH_SHORT).show();

        //condition
        if (celsius>99){
            //do something here,you are boiling
            condition = "Hot";
            ivIcon.setImageResource(R.drawable.icon_hot);
            Toast.makeText(ConvertActivity.this,"Boiling Here", Toast.LENGTH_SHORT).show();

        }

        else if(celsius<0){
            //do something here,you are freezing
            condition = "Freezing";
            ivIcon.setImageResource(R.drawable.icon_cold);
            Toast.makeText(ConvertActivity.this,"Freezing Here", Toast.LENGTH_SHORT).show();
        }


        else{
            //its all fine here
            condition = "Normal";
            ivIcon.setImageResource(R.drawable.icon_nice);
            Toast.makeText(ConvertActivity.this, "Nice Temperature", Toast.LENGTH_SHORT).show();

        }







    }
}
