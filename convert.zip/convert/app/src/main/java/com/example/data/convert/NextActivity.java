package com.example.data.convert;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class NextActivity extends AppCompatActivity {

    //step1 : declare variable
    TextView tvCelsius;
    ImageView img;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);


        Intent i = getIntent();
        //receive data
       double value = i.getDoubleExtra("key", 0.0);
       //declare variable value&receive.
        //step2 : initialize variable


        tvCelsius= findViewById(R.id.textViewCelsiusValue);
        img = findViewById(R.id.imageViewNextActivity);



        //dalam activity convertactivity akan di set ke nextactivity
        //tvCelsius.setText("Receive value is: " + value);

        Bundle bundle = getIntent().getExtras();
        String receivedString = bundle.getString("key1");
        double receivedTemp = bundle.getDouble("key2");
        tvCelsius.setText("\nThe condition is : " + receivedString + "\nThe Temp is :" + receivedTemp);





        if (receivedTemp>99){

            img.setImageResource(R.drawable.icon_hot);

        }

        else if(receivedTemp<0){

            img.setImageResource(R.drawable.icon_cold);
        }


        else{

            img.setImageResource(R.drawable.icon_nice);


        }












    }
}
