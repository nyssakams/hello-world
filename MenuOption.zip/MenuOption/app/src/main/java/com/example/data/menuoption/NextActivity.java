package com.example.data.menuoption;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;

public class NextActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Log.e("NextActivity","OnCreate"); //paste pada semua onstart smpai ondestroy


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }




    //copy daripada Main Activity
    //untuk application to start,stop,pause,resume,destroy
    @Override
    protected void onStart() {
        super.onStart();
        Log.e("NextActivity","onStart");
    }

    //create new method onResume
    @Override
    protected void onResume() {
        super.onResume();
        Log.e("NextActivity","OnResume");
    }

    //create new method onPause
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("NextActivity","OnPause");
    }

    //create new method onStop
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("NextActivity","OnStop");
    }

    //create new method onDestroy
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("NextActivity","OnDestroy");
    }




}
