package com.example.data.menuoption;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Log.e("MainActivity","onCreate"); //add log e to see the log. add Log e in every method(onstart sampai ondestroy)

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                //untuk floating button to the next activity/layout
                Intent i = new Intent(MenuActivity.this, NextActivity.class);
                startActivity(i);
            }
        });
    }








    //untuk application to start,stop,pause,resume,destroy
    //create new method onStart
    @Override
    protected void onStart() {
        super.onStart();
        Log.e("MenuActivity","onStart");
    }

    //create new method onResume
    @Override
    protected void onResume() {
        super.onResume();
        Log.e("MenuActivity","OnResume");
    }

    //create new method onPause
    @Override
    protected void onPause() {
        super.onPause();
        Log.e("MenuActivity","OnPause");
    }

    //create new method onStop
    @Override
    protected void onStop() {
        super.onStop();
        Log.e("MenuActivity","OnStop");
    }

    //create new method onDestroy
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("MenuActivity","OnDestroy");
    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //written a boolean
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Toast.makeText(this,"Settings", Toast.LENGTH_SHORT).show();      //capital T (1st option) pastu isi text "Settings"
            return true;
        }

        else if (id == R.id.action_edit) {
            Toast.makeText(this, "Edit", Toast.LENGTH_SHORT).show();    //capital T (1st option) pastu isi text "Edit"
            return true;
        }




        return super.onOptionsItemSelected(item);
    }
}
