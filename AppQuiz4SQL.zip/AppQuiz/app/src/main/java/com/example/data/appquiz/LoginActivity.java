package com.example.data.appquiz;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {


    Button btLogin;
    Button btSignUp;
    EditText etUsername, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        btLogin = findViewById(R.id.buttonLogin); //R.id.buttonLogin ni adalah id button kat att
        btSignUp = findViewById(R.id.buttonSignUp);
        etUsername = findViewById(R.id.editTextUsername);
        etPassword = findViewById(R.id.editTextPassword);




        btSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String stUsername = etUsername.getText().toString();
                String stPassword = etPassword.getText().toString();
                SharedPreferences sp = getApplicationContext().getSharedPreferences("MyData", MODE_PRIVATE); // mode private sebab tak nak share data dengan org lain. sp object

                SharedPreferences.Editor editor = sp.edit(); //editor object. to put the data in editor.
                editor.putString("username", stUsername); //username tu key. refactor>extract>constant (kalau ada dalam file lain boleh tukar guna ni)
                editor.putString("password", stPassword);
                editor.commit(); // to save data


              Snackbar.make(view, "Sign Up Successful", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();


            }
        });




        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                SharedPreferences sp = getApplicationContext().getSharedPreferences("MyData",MODE_PRIVATE); //save data kita pada MYDATA(database kita)

                String username = sp.getString("username","DefaultValue");
                String password = sp.getString("password","DefaultValue");
               // Toast.makeText(LoginActivity.this,"User: "+ username+ "Pass:"+ password, Toast.LENGTH_SHORT);          //setText to show apa


                String typedUsername = etUsername.getText().toString(); // sama tak user tu taip username&password dengan sp code atas ni
                String typedPassword = etPassword.getText().toString();


                //condition login fail or successful
                if(typedUsername.equals(username) && typedPassword.equals(password)){

                    Intent i = new Intent(LoginActivity.this,MainMenuActivity.class);
                    startActivity(i);
                    Toast.makeText(LoginActivity.this,"Login Successful", Toast.LENGTH_SHORT).show();
                }

                else{
                    Snackbar.make(view, "Login Failed", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();


                }







            }
        });







        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}
